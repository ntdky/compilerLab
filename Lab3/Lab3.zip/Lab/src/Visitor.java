import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.RuleContext;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.tree.RuleNode;
import org.antlr.v4.runtime.tree.TerminalNode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Visitor extends SysYParserBaseVisitor<Void> {

    private int depth = 0;
    private boolean isError = false;
    private GlobalScope globalScope = null;
    private Scope currentScope = null;
    private int localScopeCounter = 0;
    private final List<Object> printMsg = new ArrayList<>();

    public List<Object> getPrintMsg() {
        return printMsg;
    }

    public boolean isError() {
        return isError;
    }

    private String getColor(String name) {
        switch (name) {
            case "CONST":
            case "INT":
            case "VOID":
            case "IF":
            case "ELSE":
            case "WHILE":
            case "BREAK":
            case "CONTINUE":
            case "RETURN": {
                return "[orange]";
            }
            case "PLUS":
            case "MINUS":
            case "MUL":
            case "DIV":
            case "MOD":
            case "ASSIGN":
            case "EQ":
            case "NEQ":
            case "LT":
            case "GT":
            case "LE":
            case "GE":
            case "NOT":
            case "AND":
            case "OR": {
                return "[blue]";
            }
            case "IDENT": {
                return "[red]";
            }
            case "INTEGER_CONST": {
                return "[green]";
            }
            default: {
                return null;
            }
        }
    }

    private String parseNumber(String numberStr) {
        if (numberStr.startsWith("0x") || numberStr.startsWith("0X")) {
            numberStr = String.valueOf(Integer.parseInt(numberStr.substring(2), 16));
        } else if (numberStr.startsWith("0")) {
            numberStr = String.valueOf(Integer.parseInt(numberStr, 8));
        }
        return numberStr;
    }

    private void printError(int typeNo, int lineNo, String message) {
        System.err.println("Error type " + typeNo + " at Line " + lineNo + ": " + message + ".");
        isError = true;
    }

    private String generatePrefix(int depth) {
        return String.join("", Collections.nCopies(depth, "  "));
    }

    @Override
    public Void visitChildren(RuleNode node) {
        RuleContext ctx = node.getRuleContext();
        int ruleIndex = ctx.getRuleIndex();
        String ruleName = SysYParser.ruleNames[ruleIndex];
        String realName = ruleName.substring(0, 1).toUpperCase() + ruleName.substring(1);
        printMsg.add(generatePrefix(depth) + realName);

        depth++;
        Void ret = super.visitChildren(node);
        depth--;

        return ret;
    }

    @Override
    public Void visitTerminal(TerminalNode node) {
        Token token = node.getSymbol();
        int ruleNum = token.getType() - 1;

        if (ruleNum < 0) {
            return super.visitTerminal(node);
        }

        String ruleName = SysYLexer.ruleNames[ruleNum];
        String tokenText = token.getText();
        String color = getColor(ruleName);
        Symbol symbol = currentScope.getSymbol(tokenText);

        if (ruleName.equals("INTEGER_CONST")) {
            tokenText = parseNumber(tokenText);
        }

        if (!(color == null)) {
            String temp = generatePrefix(depth);
            if (symbol == null) {
                temp += tokenText;
            } else {
                temp += symbol.getName();
            }
            printMsg.add(temp + " " + ruleName + color);
        }

        return super.visitTerminal(node);
    }

    @Override
    public Void visitProgram(SysYParser.ProgramContext ctx) {
        globalScope = new GlobalScope(null);
        currentScope = globalScope;
        Void ret = super.visitProgram(ctx);
        currentScope = currentScope.getEnclosingScope();
        return ret;
    }

    @Override
    public Void visitFuncDef(SysYParser.FuncDefContext ctx) {
        String funcName = ctx.IDENT().getText();
        if (currentScope.isHaveSymbol(funcName)) {
            printError(4, getLineNo(ctx), "Redefined function: " + funcName);
            return null;
        }

        String retTypeName = ctx.funcType().getText();
        Type retType = (Type) globalScope.getSymbol(retTypeName);
        ArrayList<Type> paramsType = new ArrayList<>();
        FunctionType functionType = new FunctionType(retType, paramsType);
        FunctionSymbol functionSymbol = new FunctionSymbol(funcName, currentScope, functionType);
        currentScope.putSymbol(functionSymbol);
        currentScope = functionSymbol;
        Void ret = super.visitFuncDef(ctx);
        currentScope = currentScope.getEnclosingScope();
        return ret;
    }

    @Override
    public Void visitBlock(SysYParser.BlockContext ctx) {
        LocalScope localScope = new LocalScope(currentScope);
        String localScopeName = localScope.getName() + localScopeCounter;
        localScope.setName(localScopeName);
        localScopeCounter++;
        currentScope = localScope;
        Void ret = super.visitBlock(ctx);
        currentScope = currentScope.getEnclosingScope();
        return ret;
    }

    int getLineNo(ParserRuleContext ctx) {
        return ctx.getStart().getLine();
    }

    @Override
    public Void visitVarDecl(SysYParser.VarDeclContext ctx) {
        String typeName = ctx.bType().getText();

        for (SysYParser.VarDefContext varDefContext : ctx.varDef()) {
            Type varType = (Type) globalScope.getSymbol(typeName);
            String varName = varDefContext.IDENT().getText();
            if (currentScope.isHaveSymbol(varName)) {
                printError(3, getLineNo(varDefContext), "Redefined variable: " + varName);
                continue;
            }

            for (SysYParser.ConstExpContext constExpContext : varDefContext.constExp()) {
                int elementCount = Integer.parseInt(parseNumber(constExpContext.getText()));
                varType = new ArrayType(elementCount, varType);
            }

            if (varDefContext.ASSIGN() != null) {
                SysYParser.ExpContext expContext = varDefContext.initVal().exp();
                if (expContext != null) {
                    Type initValType = parseExpType(expContext);
                    if (!initValType.toString().equals(Constant.NoTYPE) && !varType.toString().equals(initValType.toString())) {
                        printError(5, getLineNo(varDefContext), "Type mismatched for assignment");
                    }
                }
            }

            VariableSymbol varSymbol = new VariableSymbol(varName, varType);
            currentScope.putSymbol(varSymbol);
        }

        return super.visitVarDecl(ctx);
    }

    @Override
    public Void visitConstDecl(SysYParser.ConstDeclContext ctx) {
        String typeName = ctx.bType().getText();

        for (SysYParser.ConstDefContext varDefContext : ctx.constDef()) {
            Type constType = (Type) globalScope.getSymbol(typeName);
            String constName = varDefContext.IDENT().getText();

            if (currentScope.isHaveSymbol(constName)) {
                printError(3, getLineNo(varDefContext), "Redefined variable: " + constName);
                continue;
            }

            for (SysYParser.ConstExpContext constExpContext : varDefContext.constExp()) {
                int elementCount = Integer.parseInt(parseNumber(constExpContext.getText()));
                constType = new ArrayType(elementCount, constType);
            }
            SysYParser.ConstExpContext expContext = varDefContext.constInitVal().constExp();

            if (expContext != null) {
                Type initValType = parseExpType(expContext.exp());
                if (!initValType.toString().equals(Constant.NoTYPE) && !constType.toString().equals(initValType.toString())) {
                    printError(5, getLineNo(varDefContext), "Type mismatched for assignment");
                }
            }

            VariableSymbol constSymbol = new VariableSymbol(constName, constType);
            currentScope.putSymbol(constSymbol);
        }

        return super.visitConstDecl(ctx);
    }

    @Override
    public Void visitFuncFParam(SysYParser.FuncFParamContext ctx) {
        String varTypeName = ctx.bType().getText();
        Type varType = (Type) globalScope.getSymbol(varTypeName);
        for (TerminalNode ignored : ctx.L_BRACKT()) {
            varType = new ArrayType(0, varType);
        }
        String varName = ctx.IDENT().getText();
        VariableSymbol varSymbol = new VariableSymbol(varName, varType);

        if (currentScope.isHaveSymbol(varName)) {
            printError(3, getLineNo(ctx), "Redefined variable: " + varName);
        } else {
            currentScope.putSymbol(varSymbol);
            ((FunctionSymbol) currentScope).getType().getParamsType().add(varType);
        }
        return super.visitFuncFParam(ctx);
    }

    private Type parseLValType(SysYParser.LValContext ctx) {
        String varName = ctx.IDENT().getText();
        Symbol symbol = currentScope.getSymbol(varName);
        if (symbol == null) {
            return new BasicTypeSymbol(Constant.NoTYPE);
        }
        Type varType = symbol.getType();
        for (SysYParser.ExpContext ignored : ctx.exp()) {
            if (varType instanceof ArrayType) {
                varType = ((ArrayType) varType).elementType;
            } else {
                return new BasicTypeSymbol(Constant.NoTYPE);
            }
        }
        return varType;
    }


    @Override
    public Void visitLVal(SysYParser.LValContext ctx) {
        String varName = ctx.IDENT().getText();
        Symbol symbol = currentScope.getSymbol(varName);
        if (symbol == null) {
            printError(1, getLineNo(ctx), "Undefined variable: " + varName);
            return null;
        }
        Type varType = symbol.getType();
        int arrayDimension = ctx.exp().size();
        for (int i = 0; i < arrayDimension; i++) {
            if (varType instanceof ArrayType) {
                varType = ((ArrayType) varType).elementType;
                SysYParser.ExpContext expContext = ctx.exp(i);
                varName += "[" + expContext.getText() + "]";
            } else {
                printError(9, getLineNo(ctx), "Not an array: " + varName);
                break;
            }
        }

        return super.visitLVal(ctx);
    }

    @Override
    public Void visitStmt(SysYParser.StmtContext ctx) {
        if (ctx.ASSIGN() != null) {
            Type lValType = parseLValType(ctx.lVal());
            Type rValType = parseExpType(ctx.exp());
            if (lValType instanceof FunctionType) {
                printError(11, getLineNo(ctx), "The left-hand side of an assignment must be a variable");
            } else if (!lValType.toString().equals(Constant.NoTYPE) && !rValType.toString().equals(Constant.NoTYPE) && !lValType.toString().equals(rValType.toString())) {
                printError(5, getLineNo(ctx), "Type mismatched for assignment");
            }
        } else if (ctx.RETURN() != null) {
            Type retType = new BasicTypeSymbol(Constant.VOID);
            if (ctx.exp() != null) {
                retType = parseExpType(ctx.exp());
            }

            Scope temp = currentScope;
            while (!(temp instanceof FunctionSymbol)) {
                temp = temp.getEnclosingScope();
            }

            Type expectedType = ((FunctionSymbol) temp).getType().getRetType();
            if (!retType.toString().equals(Constant.NoTYPE) && !expectedType.toString().equals(Constant.NoTYPE) && !retType.toString().equals(expectedType.toString())) {
                printError(7, getLineNo(ctx), "Type mismatched for return");
            }
        }
        return super.visitStmt(ctx);
    }

    private Type parseExpType(SysYParser.ExpContext ctx) {
        if (ctx.IDENT() != null) { // IDENT L_PAREN funcRParams? R_PAREN
            String funcName = ctx.IDENT().getText();
            Symbol symbol = currentScope.getSymbol(funcName);
            if (symbol != null && symbol.getType() instanceof FunctionType) {
                FunctionType functionType = (FunctionType) currentScope.getSymbol(funcName).getType();
                ArrayList<Type> paramsType = functionType.getParamsType(), argsType = new ArrayList<>();
                if (ctx.funcRParams() != null) {
                    for (SysYParser.ParamContext paramContext : ctx.funcRParams().param()) {
                        argsType.add(parseExpType(paramContext.exp()));
                    }
                }
                if (paramsType.equals(argsType)) {
                    return functionType.getRetType();
                }
            }
        } else if (ctx.L_PAREN() != null) { // L_PAREN exp R_PAREN
            return parseExpType(ctx.exp(0));
        } else if (ctx.unaryOp() != null) { // unaryOp exp
            return parseExpType(ctx.exp(0));
        } else if (ctx.lVal() != null) { // lVal
            return parseLValType(ctx.lVal());
        } else if (ctx.number() != null) { // number
            return new BasicTypeSymbol(Constant.INT);
        } else if (ctx.MUL() != null || ctx.DIV() != null || ctx.MOD() != null || ctx.PLUS() != null || ctx.MINUS() != null) {
            Type op1Type = parseExpType(ctx.exp(0));
            Type op2Type = parseExpType(ctx.exp(1));
            if (op1Type.toString().equals(Constant.INT) && op2Type.toString().equals(Constant.INT)) {
                return op1Type;
            }
        }
        return new BasicTypeSymbol(Constant.NoTYPE);
    }

    private boolean checkArgsTypes(ArrayList<Type> paramsType, ArrayList<Type> argsType) {
        for (Type type : paramsType) {
            if (type.toString().equals(Constant.NoTYPE)) {
                return true;
            }
        }
        for (Type type : argsType) {
            if (type.toString().equals(Constant.NoTYPE)) {
                return true;
            }
        }
        if (paramsType.size() != argsType.size()) {
            return false;
        }
        for (int i = 0; i < paramsType.size(); ++i) {
            Type paramType = paramsType.get(i);
            Type argType = argsType.get(i);
            if (!paramType.toString().equals(argType.toString())) {
                return false;
            }
        }
        return true;
    }

    @Override
    public Void visitExp(SysYParser.ExpContext ctx) {
        if (ctx.IDENT() != null) { // IDENT L_PAREN funcRParams? R_PAREN
            String funcName = ctx.IDENT().getText();
            Symbol symbol = currentScope.getSymbol(funcName);
            if (symbol == null) {
                printError(2, getLineNo(ctx), "Undefined function: " + funcName);
            } else if (!(symbol.getType() instanceof FunctionType)) {
                printError(10, getLineNo(ctx), "Not a function: " + funcName);
            } else {
                FunctionType functionType = (FunctionType) symbol.getType();
                ArrayList<Type> paramsType = functionType.getParamsType();
                ArrayList<Type> argsType = new ArrayList<>();
                if (ctx.funcRParams() != null) {
                    for (SysYParser.ParamContext paramContext : ctx.funcRParams().param()) {
                        argsType.add(parseExpType(paramContext.exp()));
                    }
                }
                if (!checkArgsTypes(paramsType, argsType)) {
                    printError(8, getLineNo(ctx), "Function is not applicable for arguments");
                }
            }
        } else if (ctx.MUL() != null || ctx.DIV() != null || ctx.MOD() != null || ctx.PLUS() != null || ctx.MINUS() != null) {
            Type op1Type = parseExpType(ctx.exp(0)), op2Type = parseExpType(ctx.exp(1));
            boolean flag = ((op1Type.toString().equals(Constant.NoTYPE) || op2Type.toString().equals(Constant.NoTYPE))
                    || (op1Type.toString().equals(Constant.INT) && op2Type.toString().equals(Constant.INT)));
            if (!flag) {
                printError(6, getLineNo(ctx), "Type mismatched for operands");
            }
        } else if (ctx.unaryOp() != null) { // unaryOp exp
            Type expType = parseExpType(ctx.exp(0));
            if (!expType.toString().equals(Constant.INT)) {
                printError(6, getLineNo(ctx), "Type mismatched for operands");
            }
        }
        return super.visitExp(ctx);
    }

    private Type getCondType(SysYParser.CondContext ctx) {
        if (ctx.exp() != null) {
            return parseExpType(ctx.exp());
        }

        Type cond1 = getCondType(ctx.cond(0));
        Type cond2 = getCondType(ctx.cond(1));
        if (cond1.toString().equals(Constant.INT) && cond2.toString().equals(Constant.INT)) {
            return cond1;
        }
        return new BasicTypeSymbol(Constant.NoTYPE);
    }

    @Override
    public Void visitCond(SysYParser.CondContext ctx) {
        if (ctx.exp() == null && !getCondType(ctx).toString().equals(Constant.INT)) {
            printError(6, getLineNo(ctx), "Type mismatched for operands");
        }
        return super.visitCond(ctx);
    }
}
