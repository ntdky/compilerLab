public class Constant {
    public static final String INT = "int";

    public static final String VOID = "void";

    public static final String NoTYPE = "noType";

    public static final String GlobalScope = "GlobalScope";
}
