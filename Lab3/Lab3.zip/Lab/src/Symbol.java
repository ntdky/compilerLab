public interface Symbol {
	
	String getName();
	
	Type getType();
}
