public interface Type {
}